from django.urls import path
from . import views 
urlpatterns = [
    path ('', views.register, name='register'),
    path ('settings', views.settings, name='settings'),
    path ('login', views.login, name='login'),
    path ('logout', views.logout, name='logout'), 
    path ('upload', views.upload, name='upload'),
    path ('profile/<str:pk>', views.profile, name='profile'),
    path('messageroom', views.messageroom, name='messageroom'),
    path('home', views.home, name='home'),
    path('follow', views.follow, name='follow'),
    path('like-post', views.like_post, name='like-post'),
    path('search', views.search, name='search'),
    path('send', views.send, name='send'),
    path('getMessages', views.getMessages, name='getMessages'),
    path('compose_message', views.compose_message, name='compose_message'),
    ]